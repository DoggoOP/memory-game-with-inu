
//
//  GameViewController.swift
//  Memory Card Game
//
//  Created by Inesh Shankar Narayanan on 27/11/2021.
//  Copyright © 2021 Inesh Shankar Narayanan. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class ViewController2: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func btnImagePicker(_ sender: Any) {
        let picker = UIImagePickerController()
        
        picker.allowsEditing = true
        
        picker.delegate = self
        
        present(picker, animated: true)
    
    }
    
   
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage else {return}
        imageView.image = image
        
        dismiss(animated: true)
        
        
        
    }
    
}
