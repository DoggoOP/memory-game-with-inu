//
//  GameScene.swift
//  Memory Card Game
//
//  Created by Inesh Shankar Narayanan on 27/11/2021.
//  Copyright © 2021 Inesh Shankar Narayanan. All rights reserved.


import SpriteKit
import GameplayKit


enum GameState{
    case arranging_cards,
    turn_in_progress,
    waiting_for_action,
    game_over
}

enum CardLevel :CGFloat {
  case board = 10
  case moving = 100
  case enlarged = 200
}

struct PhysicsCategory{
    static let Button: UInt32 = 0b1
}

class GameScene: SKScene {
    
    let correctmatchlabel = SKLabelNode(fontNamed: "Arial")
    let incorrectmatchlabel = SKLabelNode(fontNamed: "Arial")
    let clicksleft = SKLabelNode(fontNamed: "Arial")
    let scorelabel = SKLabelNode(fontNamed: "Arial")
    let death = SKLabelNode(fontNamed: "Arial")
    let win = SKLabelNode(fontNamed: "Arial")

    var clicks = 24 // testing purposes
    
    let wait = SKAction.wait(forDuration: 2.5)
    
    var gameState = GameState.arranging_cards
    
    var cards : [Card] = []
    var flippedCards: [Card] = []
    var score = 0
    
    var offsetX = -185;
    var offsetY = -400;
    var cardWidth = 120;
    var cardHeight = 220;
    
    var rows = 4;
    var cols = 4;
    
    let queue = DispatchQueue.global(qos: .background) // or some higher QOS level
    
    var CardList = [1, 2, 3, 4, 5, 6, 7, 8]
    
    
/*
    func getRandomCardType(index : Int)->CardType{
                        if(index % 8 == 0) {
                                return CardType.monkey
                            }
                            else if(index % 8 == 1){
                                return CardType.swan
                            }
                            else if(index % 8 == 2){
                                return CardType.elephant
                            }
                            else if(index % 8 == 3){
                                return CardType.horse
                            }
                            else if(index % 8 == 4){
                                return CardType.owl
                            }
                            else if(index % 8 == 5){
                                return CardType.pig
                            }
                            else if(index % 8 == 6){
                                return CardType.snake
                            }
                            else{
                                return CardType.dog
                            }
                }
        
        }
      */

    

    
    let playAgainBtn = SKSpriteNode(imageNamed: "play again")
    
    override func didMove(to view: SKView) {
        myCards.shuffle()
        
        myCards[0].position = CGPoint(x: -185, y: 260)
        addChild(myCards[0])
        myCards[0].animateToPosition()
        
        myCards[1].position = CGPoint(x: -65, y: 260)
        addChild(myCards[1])
        myCards[1].animateToPosition()
        
        myCards[2].position = CGPoint(x: 55, y: 260)
        addChild(myCards[2])
        myCards[2].animateToPosition()
        
        myCards[3].position = CGPoint(x: 175, y: 260)
        addChild(myCards[3])
        myCards[3].animateToPosition()
        
        myCards[4].position = CGPoint(x: -185, y: 40)
        addChild(myCards[4])
        myCards[4].animateToPosition()
        
        myCards[5].position = CGPoint(x: -65, y: 40)
        addChild(myCards[5])
        myCards[5].animateToPosition()
        
        myCards[6].position = CGPoint(x: 55, y: 40)
        addChild(myCards[6])
        myCards[6].animateToPosition()
        
        myCards[7].position = CGPoint(x: 175, y: 40)
        addChild(myCards[7])
        myCards[7].animateToPosition()
        
        myCards[8].position = CGPoint(x: -185, y: -180)
        addChild(myCards[8])
        myCards[8].animateToPosition()
        
        myCards[9].position = CGPoint(x: -65, y: -180)
        addChild(myCards[9])
        myCards[9].animateToPosition()
        
        myCards[10].position = CGPoint(x: 55, y: -180)
        addChild(myCards[10])
        myCards[10].animateToPosition()
        
        myCards[11].position = CGPoint(x: 175, y: -180)
        addChild(myCards[11])
        myCards[11].animateToPosition()
        
        myCards[12].position = CGPoint(x: -185, y: -400)
        addChild(myCards[12])
        myCards[12].animateToPosition()
        
        myCards[13].position = CGPoint(x: -65, y: -400)
        addChild(myCards[13])
        myCards[13].animateToPosition()
        
        myCards[14].position = CGPoint(x: 55, y: -400)
        addChild(myCards[14])
        myCards[14].animateToPosition()
        
        myCards[15].position = CGPoint(x: 175, y: -400)
        addChild(myCards[15])
        myCards[15].animateToPosition()
        

        
        //CardList.shuffle()
        
        correctmatchlabel.text = String("good job you matched 2 cards")
        correctmatchlabel.fontColor = UIColor.green
        correctmatchlabel.fontSize = 30
        correctmatchlabel.position = CGPoint(x: 0, y: 400)
        correctmatchlabel.isHidden = true
        correctmatchlabel.zPosition = 10
        self.addChild(correctmatchlabel)
        
        incorrectmatchlabel.text = String("oops the cards do not match try again")
        incorrectmatchlabel.fontColor = UIColor.red
        incorrectmatchlabel.fontSize = 30
        incorrectmatchlabel.position = CGPoint(x: 0, y: 400)
        incorrectmatchlabel.isHidden = true
        incorrectmatchlabel.zPosition = 10
        self.addChild(incorrectmatchlabel)
        
        clicksleft.text = String("clicks left: \(clicks)")
        clicksleft.fontColor = UIColor.white
        clicksleft.fontSize = 30
        clicksleft.position = CGPoint(x: 0, y: 500)
        clicksleft.zPosition = 10
        self.addChild(clicksleft)
        
        scorelabel.text = String("score: \(score)")
        scorelabel.fontColor = UIColor.white
        scorelabel.fontSize = 30
        scorelabel.position = CGPoint(x: 0, y: 600)
        scorelabel.zPosition = 10
        self.addChild(scorelabel)

        death.text = String("OH NO! You ran out of clicks Try again")
        death.fontColor = UIColor.red
        death.fontSize = 40
        death.position = CGPoint(x: 0, y: -100)
        death.isHidden = true
        death.zPosition = 10
        self.addChild(death)
        
        win.text = String("Good job! You matched all the cards")
        win.fontColor = UIColor.red
        win.fontSize = 35
        win.position = CGPoint(x: 0, y: -100)
        win.isHidden = true
        win.zPosition = 10
        self.addChild(win)
        
        
        playAgainBtn.setScale(0.5)
        playAgainBtn.name = "Button"
        playAgainBtn.zPosition = 10
        playAgainBtn.position = CGPoint(x: 0, y: -550)
        self.addChild(playAgainBtn)
        playAgainBtn.isHidden = true
        
        let tapRec = UITapGestureRecognizer()
        tapRec.addTarget(self, action:#selector(GameScene.tappedView(_:) ))
        tapRec.numberOfTouchesRequired = 1
        tapRec.numberOfTapsRequired = 1
        self.view!.addGestureRecognizer(tapRec)
        
        /*
        for col in 0...cols-1 {
            for row in 0...rows-1 {
                var id = row * cols + col;
                var card = Card(cardType: getRandomCardType(index: id),_id: id)
                card.name = String(id);
                card.position = CGPoint(x: (col * cardWidth) + offsetX, y : (row * cardHeight) + offsetY)
                card.animateToPosition()
                cards.append(card)
                addChild(card)
            }
            
        }
        */
         
        // Do somthing after 10.5 seconds
        queue.asyncAfter(deadline: .now() + 1.0) {
            // your task code here
            DispatchQueue.main.async {
                self.gameState = GameState.waiting_for_action
            }
        }
    }
    
    @objc func tappedView(_ sender:UITapGestureRecognizer) {

    if sender.state == .ended {
        print("State == Ended")

        var post = sender.location(in: sender.view)
        post = self.convertPoint(fromView: post)
        let touchNode = self.atPoint(post)

        if touchNode.name == "Button"
        {
            removeAllChildren()
            self.flippedCards.removeAll()
            self.view?.isPaused = false
            myCards.shuffle()
            
            myCards[0].position = CGPoint(x: -185, y: 260)
            addChild(myCards[0])
            myCards[0].animateToPosition()
            
            myCards[1].position = CGPoint(x: -65, y: 260)
            addChild(myCards[1])
            myCards[1].animateToPosition()
            
            myCards[2].position = CGPoint(x: 55, y: 260)
            addChild(myCards[2])
            myCards[2].animateToPosition()
            
            myCards[3].position = CGPoint(x: 175, y: 260)
            addChild(myCards[3])
            myCards[3].animateToPosition()
            
            myCards[4].position = CGPoint(x: -185, y: 40)
            addChild(myCards[4])
            myCards[4].animateToPosition()
            
            myCards[5].position = CGPoint(x: -65, y: 40)
            addChild(myCards[5])
            myCards[5].animateToPosition()
            
            myCards[6].position = CGPoint(x: 55, y: 40)
            addChild(myCards[6])
            myCards[6].animateToPosition()
            
            myCards[7].position = CGPoint(x: 175, y: 40)
            addChild(myCards[7])
            myCards[7].animateToPosition()
            
            myCards[8].position = CGPoint(x: -185, y: -180)
            addChild(myCards[8])
            myCards[8].animateToPosition()
            
            myCards[9].position = CGPoint(x: -65, y: -180)
            addChild(myCards[9])
            myCards[9].animateToPosition()
            
            myCards[10].position = CGPoint(x: 55, y: -180)
            addChild(myCards[10])
            myCards[10].animateToPosition()
            
            myCards[11].position = CGPoint(x: 175, y: -180)
            addChild(myCards[11])
            myCards[11].animateToPosition()
            
            myCards[12].position = CGPoint(x: -185, y: -400)
            addChild(myCards[12])
            myCards[12].animateToPosition()
            
            myCards[13].position = CGPoint(x: -65, y: -400)
            addChild(myCards[13])
            myCards[13].animateToPosition()
            
            myCards[14].position = CGPoint(x: 55, y: -400)
            addChild(myCards[14])
            myCards[14].animateToPosition()
            
            myCards[15].position = CGPoint(x: 175, y: -400)
            addChild(myCards[15])
            myCards[15].animateToPosition()
                        
            score = 0
            clicks = 24 // for testing purposes
            
            correctmatchlabel.text = String("good job you matched 2 cards")
            correctmatchlabel.fontColor = UIColor.green
            correctmatchlabel.fontSize = 30
            correctmatchlabel.position = CGPoint(x: 0, y: 400)
            correctmatchlabel.isHidden = true
            correctmatchlabel.zPosition = 10
            self.addChild(correctmatchlabel)
            
            incorrectmatchlabel.text = String("oops the cards do not match try again")
            incorrectmatchlabel.fontColor = UIColor.red
            incorrectmatchlabel.fontSize = 30
            incorrectmatchlabel.position = CGPoint(x: 0, y: 400)
            incorrectmatchlabel.isHidden = true
            incorrectmatchlabel.zPosition = 10
            self.addChild(incorrectmatchlabel)
            
            clicksleft.text = String("clicks left: \(clicks)")
            clicksleft.fontColor = UIColor.white
            clicksleft.fontSize = 30
            clicksleft.position = CGPoint(x: 0, y: 500)
            clicksleft.zPosition = 10
            self.addChild(clicksleft)
            
            scorelabel.text = String("score: \(score)")
            scorelabel.fontColor = UIColor.white
            scorelabel.fontSize = 30
            scorelabel.position = CGPoint(x: 0, y: 600)
            scorelabel.zPosition = 10
            self.addChild(scorelabel)

            death.text = String("OH NO! You ran out of clicks Try again")
            death.fontColor = UIColor.red
            death.fontSize = 40
            death.position = CGPoint(x: 0, y: -100)
            death.isHidden = true
            death.zPosition = 10
            self.addChild(death)
            
            win.text = String("Good job! You matched all the cards")
            win.fontColor = UIColor.red
            win.fontSize = 35
            win.position = CGPoint(x: 0, y: -100)
            win.isHidden = true
            win.zPosition = 10
            self.addChild(win)
            
            let playAgainBtn = SKSpriteNode(imageNamed: "play again")
            playAgainBtn.setScale(0.5)
            playAgainBtn.name = "Button"
            playAgainBtn.zPosition = 10
            playAgainBtn.position = CGPoint(x: 0, y: -550)
            self.addChild(playAgainBtn)
            playAgainBtn.isHidden = true
            
            let tapRec = UITapGestureRecognizer()
            tapRec.addTarget(self, action:#selector(GameScene.tappedView(_:) ))
            tapRec.numberOfTouchesRequired = 1
            tapRec.numberOfTapsRequired = 1
            self.view!.addGestureRecognizer(tapRec)
            
            /*
            for col in 0...cols-1 {
                for row in 0...rows-1 {
                    var id = row * cols + col;
                    //var card = Card(cardType: getRandomCardType(index: id),_id: id)
                    card.name = String(id);
                    card.position = CGPoint(x: (col * cardWidth) + offsetX, y : (row * cardHeight) + offsetY)
                    card.animateToPosition()
                    cards.append(card)
                    addChild(card)
                }
                
            }*/
            
            // Do somthing after 10.5 seconds
            queue.asyncAfter(deadline: .now() + 1.0) {
                // your task code here
                DispatchQueue.main.async {
                    self.gameState = GameState.waiting_for_action
                }
            }
                                
        }
    }
    }

    override func update(_ currentTime: TimeInterval){
        //checking if cards were flipped, if not, don't process further
        if(GameState.turn_in_progress != gameState){
            return;
        }
        
        //checking if 2 cards were fliiped
        if(flippedCards.count == 2){
            var canCheckForMatch = flippedCards[0].getState() != CardState.flipping &&
            flippedCards[1].getState() != CardState.flipping;
            if(canCheckForMatch){
                if(flippedCards[0].getType() == flippedCards[1].getType()){
                    self.score+=1;
                    correctmatchlabel.isHidden = false
                    scorelabel.text = String("score: \(score)")
                    flippedCards[0].currentState = CardState.matched;
                    flippedCards[1].currentState = CardState.matched;
                    print("Your score " + String(self.score))
                    self.gameState = GameState.waiting_for_action
                    self.flippedCards.removeAll()
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                        self.correctmatchlabel.isHidden = true
                    }
                    if score == 8 {
                        win.isHidden = false
                        view?.isPaused = true
                    }
                }
                else{
                    self.gameState = GameState.waiting_for_action
                    incorrectmatchlabel.isHidden = false
                    print("oops! cards didn't match")
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                        self.incorrectmatchlabel.isHidden = true
                    }
                    queue.asyncAfter(deadline: .now() + 1.0) {
                        // your task code here
                        DispatchQueue.main.async {
                            self.flippedCards[0].flip()
                            self.flippedCards[1].flip()
                            self.flippedCards.removeAll()
                        }
                    }
                    
                   
                }
            }
           
        }
    }
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if(gameState != GameState.waiting_for_action) {
            return;
        }
        
      for touch in touches {
        var location = touch.location(in: self)
          
          
          location.x -= CGFloat(cardWidth/2)
         // location.y -= CGFloat(cardHeight/2)
          if let card = atPoint(location) as? Card{
              if( self.flippedCards.count < 2 && (card.getState() != CardState.flipping && card.getState() != CardState.matched)){
                    clicks = clicks - 1
                  clicksleft.text = String("clicks left: \(clicks)")
                    card.flip()
                    self.flippedCards.append(card)
                  if(self.flippedCards.count == 2){
                      self.gameState = GameState.turn_in_progress
                  }
                      
                }
          }
          if clicks <= 0 {
              death.isHidden = false
              playAgainBtn.isHidden = false
              DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                  self.view?.isPaused = true
              }
        }
      }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
      for touch in touches {
        let location = touch.location(in: self)
//        if let card = atPoint(location) as? Card {
//          card.zPosition = CardLevel.board.rawValue
//          card.removeFromParent()
//          addChild(card)
//        }
      }
    }

   
}
