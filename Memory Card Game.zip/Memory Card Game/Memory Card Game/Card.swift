//
//  Card.swift
//  Memory Card Game
//
//  Created by Inesh Shankar Narayanan on 27/11/2021.
//  Copyright © 2021 Inesh Shankar Narayanan. All rights reserved.
//

import Foundation

import SpriteKit

enum CardType :Int {
  case swan = 0, monkey, elephant, horse, dog, snake, pig, owl
}

enum CardState : Int{
    case facing_up,facing_down,flipping,matched
}


class Card : SKSpriteNode {

    var id = -1;
  let cardType :CardType
  let frontTexture :SKTexture
  let backTexture :SKTexture
  var currentState : CardState
    

    func animateToPosition(){
        let finalPoint = self.position;
        self.position.x -= CGFloat(500);
        var moveAction = SKAction.move(to: finalPoint, duration: TimeInterval(CGFloat(self.id) * 0.1))
//        var moveAction = SKAction.move(to: finalPoint, duration: CGFloat(self.id) * 0.1)
        moveAction.timingMode = SKActionTimingMode.easeIn;
        moveAction.timingFunction = { time -> Float in
            return sin(time * .pi/2)
        }
        run(moveAction)
    }
    
  required init?(coder aDecoder: NSCoder) {
    fatalError("NSCoding not supported")
  }

    init(cardType: CardType, _id : Int) {
    self.id = _id;
    self.cardType = cardType
    self.currentState = CardState.facing_down
        
    self.backTexture = SKTexture(imageNamed: "card back")
    
  
    switch cardType {
    case .swan:
        frontTexture = SKTexture(imageNamed: "Swan")
    case .monkey:
        frontTexture = SKTexture(imageNamed: "Monkey")
    case .elephant:
        frontTexture = SKTexture(imageNamed: "Elephant")
    case .horse:
        frontTexture = SKTexture(imageNamed: "Horse")
    case .dog:
        frontTexture = SKTexture(imageNamed: "Dog")
    case .snake:
        frontTexture = SKTexture(imageNamed: "Snake")
    case .pig:
        frontTexture = SKTexture(imageNamed: "Pig")
    case .owl:
        frontTexture = SKTexture(imageNamed: "Owl")
    }

      super.init(texture: backTexture, color: .clear, size: backTexture.size())
        
    }
    
    func getId()->Int{
        return self.id;
    }
    
    func getType() -> CardType {
        return cardType;
    }
    
    func getState()-> CardState{
        return currentState;
    }

    func switchTexture(n:SKNode,d:CGFloat){
        if(self.texture == self.frontTexture){
            self.texture = self.backTexture
        }
        else{
            self.texture = self.frontTexture
        }
        
    }

    func flip() {
        let flipHalf = SKAction.scaleX(to: 0.0, duration: 0.4)
        let switchTexAction = SKAction.customAction(withDuration: 0, actionBlock: switchTexture)
      let flipFull = SKAction.scaleX(to: 1.0, duration: 0.4)
     let sequence = SKAction.sequence([flipHalf, switchTexAction,flipFull])
      setScale(1.0)

        self.currentState = CardState.flipping
        run(sequence,completion: {
            if self.currentState == CardState.facing_up{
                self.currentState = CardState.facing_down
            }
            else{
                self.currentState = CardState.facing_up
            }
        })
          
    }
}

var CardList = [CardType.snake, CardType.monkey, CardType.elephant, CardType.horse, CardType.dog, CardType.snake, CardType.pig, CardType.owl]
